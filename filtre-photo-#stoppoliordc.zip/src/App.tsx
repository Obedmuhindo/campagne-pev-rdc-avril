/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Upload, Download, ZoomIn, Move, RefreshCcw, RotateCcw } from 'lucide-react';
import { motion } from 'motion/react';

// Official Campaign Colors
const COLORS = {
  blue: '#1a2fbe',
  orange: '#f05a28',
};

// Assets names as provided by the user
const ASSETS = {
  logo: '/logo.png',
  filter: '/filtre.png',
};

export default function App() {
  const [userImage, setUserImage] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [posX, setPosX] = useState(0);
  const [posY, setPosY] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [filterLoaded, setFilterLoaded] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  // Coordonnées approximatives du centre du cercle pour le placement initial
  const FRAME = {
    x: 0.250, // Centre X (25%)
    y: 0.335, // Centre Y (33.5%)
  };

  // Vérification du chargement du filtre
  useEffect(() => {
    const img = new Image();
    img.src = ASSETS.filter;
    img.onload = () => setFilterLoaded(true);
    img.onerror = () => setFilterLoaded(false);
  }, []);

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUserImage(event.target?.result as string);
        // Reset controls on new image
        setZoom(1);
        setPosX(0); // Center by default
        setPosY(0);
      };
      reader.readAsDataURL(file);
    }
  };

  const resetControls = () => {
    setZoom(1);
    setPosX(0);
    setPosY(0);
  };

  // Export the final image
  const handleDownload = async () => {
    if (!canvasRef.current || !userImage) return;
    setIsExporting(true);

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set high resolution for export (1080x1080px as requested)
    canvas.width = 1080;
    canvas.height = 1080;

    try {
      // Nettoyage du canvas
      ctx.clearRect(0, 0, 1080, 1080);

      // 1. Dessiner la photo de l'utilisateur (Arrière-plan - Pleine taille)
      const img = new Image();
      img.src = userImage;
      await new Promise((resolve) => (img.onload = resolve));

      const previewWidth = previewRef.current?.getBoundingClientRect().width || 400;
      const scaleFactor = 1080 / previewWidth;

      // Calcul des dimensions pour couvrir le canvas
      const scale = Math.max(1080 / img.width, 1080 / img.height) * zoom;
      const drawWidth = img.width * scale;
      const drawHeight = img.height * scale;
      
      const x = (1080 - drawWidth) / 2 + (posX * scaleFactor);
      const y = (1080 - drawHeight) / 2 + (posY * scaleFactor);

      ctx.drawImage(img, x, y, drawWidth, drawHeight);

      // 2. Dessiner le filtre original (Premier plan avec sa transparence native)
      const filterImg = new Image();
      filterImg.src = ASSETS.filter;
      await new Promise((resolve) => {
        filterImg.onload = resolve;
        filterImg.onerror = () => resolve(null);
      });

      if (filterImg.complete && filterImg.naturalWidth > 0) {
        ctx.drawImage(filterImg, 0, 0, 1080, 1080);
      }

      // 3. Téléchargement
      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      const link = document.createElement('a');
      link.download = `StopPolioRDC_${Date.now()}.jpg`;
      link.href = dataUrl;
      link.click();
    } catch (error) {
      console.error('Export error:', error);
      alert('Erreur lors de l\'exportation. Vérifiez que les fichiers logo.png et filtre.png sont bien chargés.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-gray-50 pb-12">
      {/* Header */}
      <header className="w-full bg-white shadow-sm py-4 px-6 flex flex-col items-center space-y-3 border-b-4 border-pev-blue">
        <img 
          src={ASSETS.logo} 
          alt="Ministère de la Santé RDC" 
          className="h-16 object-contain max-w-full"
          onError={(e) => (e.currentTarget.style.display = 'none')}
        />
        <h1 className="text-xl md:text-2xl font-bold text-pev-blue text-center uppercase tracking-tight">
          Générez votre visuel <span className="text-pev-orange">#StopPolioRDC</span>
        </h1>
      </header>

      <main className="w-full max-w-md px-4 mt-6 space-y-6">
        {/* Preview Area */}
        <div 
          ref={previewRef}
          className="relative aspect-square w-full bg-white rounded-2xl shadow-2xl overflow-hidden border-4 border-white"
        >
          {/* Couche Photo Utilisateur (Arrière-plan - Pleine taille ajustable) */}
          <div className="absolute inset-0 z-0 flex items-center justify-center bg-gray-100">
            {userImage && (
              <motion.img
                src={userImage}
                alt="Aperçu"
                className="max-w-none min-w-full min-h-full object-cover"
                style={{
                  scale: zoom,
                  x: posX,
                  y: posY,
                }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
            {!userImage && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                <Upload size={48} className="mb-2 opacity-20" />
                <p className="text-sm font-medium">Importez votre photo</p>
              </div>
            )}
          </div>

          {/* Couche Filtre (Premier plan - Cliquable à travers) */}
          <div 
            className="absolute inset-0 z-10 pointer-events-none"
            style={{
              backgroundImage: `url(${ASSETS.filter})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            {!filterLoaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-white/80">
                <div className="w-12 h-12 border-4 border-pev-blue border-t-transparent rounded-full animate-spin" />
              </div>
            )}
          </div>

          {/* Hidden Canvas for Export */}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Controls */}
        <div className="bg-white rounded-2xl p-6 shadow-lg space-y-6 border border-gray-100">
          {!userImage ? (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-5 bg-pev-blue text-white rounded-xl font-black text-lg flex items-center justify-center space-x-3 hover:bg-blue-800 transition-all transform active:scale-95 shadow-xl shadow-blue-200"
            >
              <Upload size={24} />
              <span>CHOISIR UNE PHOTO</span>
            </button>
          ) : (
            <div className="space-y-5">
              {/* Zoom Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-black text-gray-500 uppercase tracking-widest">
                  <div className="flex items-center space-x-2">
                    <ZoomIn size={14} className="text-pev-blue" />
                    <span>Ajuster le Zoom</span>
                  </div>
                  <span className="text-pev-blue font-mono">{Math.round(zoom * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="4"
                  step="0.01"
                  value={zoom}
                  onChange={(e) => setZoom(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-pev-blue"
                />
              </div>

              {/* Position X Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-black text-gray-500 uppercase tracking-widest">
                  <div className="flex items-center space-x-2">
                    <Move size={14} className="text-pev-blue" />
                    <span>Déplacer Gauche / Droite</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="-200"
                  max="200"
                  step="1"
                  value={posX}
                  onChange={(e) => setPosX(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-pev-blue"
                />
              </div>

              {/* Position Y Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-black text-gray-500 uppercase tracking-widest">
                  <div className="flex items-center space-x-2">
                    <Move size={14} className="text-pev-blue rotate-90" />
                    <span>Déplacer Haut / Bas</span>
                  </div>
                </div>
                <input
                  type="range"
                  min="-200"
                  max="200"
                  step="1"
                  value={posY}
                  onChange={(e) => setPosY(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-pev-blue"
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={resetControls}
                  className="p-3 border-2 border-gray-200 text-gray-400 rounded-xl hover:bg-gray-50 transition-colors"
                  title="Réinitialiser"
                >
                  <RotateCcw size={20} />
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 py-3 border-2 border-pev-blue text-pev-blue rounded-xl font-bold flex items-center justify-center space-x-2 hover:bg-blue-50 transition-colors"
                >
                  <RefreshCcw size={18} />
                  <span>CHANGER</span>
                </button>
                <button
                  onClick={handleDownload}
                  disabled={isExporting}
                  className="flex-[2] py-3 bg-pev-orange text-white rounded-xl font-black flex items-center justify-center space-x-2 hover:bg-orange-600 transition-all transform active:scale-95 shadow-xl shadow-orange-200 disabled:opacity-50"
                >
                  {isExporting ? (
                    <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Download size={22} />
                      <span>TÉLÉCHARGER</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="bg-blue-50 border-l-4 border-pev-blue p-4 rounded-r-xl">
          <p className="text-xs text-pev-blue font-medium leading-relaxed">
            <strong>Note :</strong> Pour un résultat optimal, utilisez une photo bien éclairée. Votre photo est traitée localement sur votre appareil et n'est pas envoyée sur nos serveurs.
          </p>
        </div>
      </main>

      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleImageUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Footer Branding */}
      <footer className="mt-12 flex flex-col items-center space-y-4 opacity-80">
        <div className="flex items-center space-x-6">
          <div className="w-10 h-10 bg-pev-blue rounded-full shadow-inner" />
          <div className="w-10 h-10 bg-pev-orange rounded-full shadow-inner" />
        </div>
        <div className="text-center">
          <p className="text-[10px] font-black tracking-[0.2em] text-gray-400 uppercase">Programme Élargi de Vaccination</p>
          <p className="text-[9px] font-bold text-gray-300 mt-1">République Démocratique du Congo • 2026</p>
        </div>
      </footer>
    </div>
  );
}
